#include <stdio.h>
#include <math.h>
#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/keyboard.h>
#include <allegro5/keycodes.h>
#include <allegro5/allegro_audio.h>
#include <allegro5/allegro_acodec.h>
#include <stdbool.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <time.h>


#define MAX_COLS 15
#define COL_WIDTH 36

// === VARIÁVEIS GLOBAIS ===
const int SCREEN_W = 1366;
const int SCREEN_H = 768;

bool game_started = false;

float enemy_move_timer = 0.0f;
const float enemy_move_interval = 0.5f; 
float enemy_step_interval = 0.3f;
int rows = 5, cols = 10;

    ALLEGRO_SAMPLE_ID musica1_id;
    ALLEGRO_SAMPLE_INSTANCE *musica2_instance = NULL;
    ALLEGRO_SAMPLE_INSTANCE *musica2_1_instance = NULL;
    ALLEGRO_SAMPLE_INSTANCE *musica2_2_instance = NULL;
    ALLEGRO_SAMPLE *musica1 = NULL;
    ALLEGRO_SAMPLE *musica2 = NULL;
    ALLEGRO_SAMPLE *musica2_1 = NULL;
    ALLEGRO_SAMPLE *musica2_2 = NULL;
    ALLEGRO_SAMPLE *sfx_shot = NULL;
    ALLEGRO_SAMPLE *sfx_button = NULL;
    ALLEGRO_SAMPLE *sfx_boom = NULL;
    ALLEGRO_DISPLAY *display = NULL;
    ALLEGRO_EVENT_QUEUE *event_queue = NULL;
    ALLEGRO_TIMER *timer = NULL;
    ALLEGRO_BITMAP *background;
    ALLEGRO_BITMAP *player_frames[4];
    ALLEGRO_BITMAP *player_left_frames[4];
    ALLEGRO_BITMAP *player_right_frames[4];
    ALLEGRO_BITMAP *player_knockback_frames[4];
    ALLEGRO_BITMAP *explosion_frames[4];
    ALLEGRO_BITMAP *player_knockback_left_frames[4];
    ALLEGRO_BITMAP *player_knockback_right_frames[4];
    ALLEGRO_BITMAP *enemy_explosion_frames[3][6];
    ALLEGRO_BITMAP *enemy_bullet_sprite;
    ALLEGRO_BITMAP *interface_Move;
    ALLEGRO_BITMAP *interface_SPACE;



typedef struct Shot {
    float x, y;
    struct Shot *next;
    int frame; 
    bool stabilized;
} Shot;

typedef struct Enemy {
    float x, y;
    int type;
    int frame;
    bool alive;
    bool exploding;
    int explosion_frame;
    float explosion_timer;
    struct Enemy *next;
} Enemy;

typedef struct EnemyShot {
    float x, y;
    struct EnemyShot *next;
} EnemyShot;

EnemyShot *enemy_shots = NULL;
Enemy *enemy_list = NULL;

bool moving_right = true;
float enemy_dx = 2.0;
float enemy_dy = 0.0;

ALLEGRO_BITMAP *enemy_sprites[3][2];
ALLEGRO_BITMAP *player_bullet_frames[4];


float enemy_scale = 2.5;
int enemy_w = 16;
int enemy_h = 16;
float enemy_anim_timer = 0.0;
float enemy_anim_interval = 0.5; 

float scale = 0.2;
int player_w = 0;
int player_h = 0;
int kb_width = 0;
int kb_height = 0;


float x = 0;  
float y = 0;


void add_shot(float x, float y, float player_w, float scale, Shot **list) {
    Shot *new_shot = malloc(sizeof(Shot));
    if (!new_shot) return;

    new_shot->x = (x + (player_w * scale) / 2 - 2); 
    new_shot->y = y - 14;
    new_shot->frame = 0;
    new_shot->stabilized = false;
    new_shot->next = *list;
    *list = new_shot;
}

void update_shots(Shot **list) {
    Shot *current = *list;
    Shot *prev = NULL;

    while (current != NULL) {
        current->y -= 7;
        if (!current->stabilized) {
            current->frame++;
            if (current->frame >= 3) {
                current->frame = 3;
                current->stabilized = true;
            }
        }
        if (current->y < 0) {
            Shot *to_remove = current;
            if (prev == NULL) {
                *list = current->next;
                current = *list;
            } else {
                prev->next = current->next;
                current = current->next;
            }
            free(to_remove);
        } else {
            prev = current;
            current = current->next;
        }
    }
}

void draw_shots(Shot *list) {
    while (list != NULL) {
        ALLEGRO_BITMAP *bmp = list->stabilized ? player_bullet_frames[3] : player_bullet_frames[list->frame];
        al_draw_scaled_bitmap(bmp, 0, 0,
        al_get_bitmap_width(bmp),
        al_get_bitmap_height(bmp),
        list->x, list->y, 12, 30, 0);
        list = list->next;
    }
}

void free_shots(Shot **list) {
    while (*list != NULL) {
        Shot *tmp = *list;
        *list = (*list)->next;
        free(tmp);
    }
}

void create_enemy_group(Enemy **list) {

    int spacing_x = COL_WIDTH ;  // espaço lateral
    int spacing_y = 37;   // espaço vertical 
    int enemy_w = 16;

    float enemy_width_scaled = enemy_w * enemy_scale;
    int total_width = (cols * enemy_width_scaled) + ((cols - 1) * spacing_x);
    int start_x = (SCREEN_W - total_width) / 2;
    int start_y = 50;
    

    for (int r = 0; r < rows; r++) {
        for (int c = 0; c < cols; c++) {
            Enemy *e = malloc(sizeof(Enemy));
            e->x = start_x + c * (enemy_width_scaled + spacing_x);
            e->y = start_y + r * (enemy_w * enemy_scale + spacing_y);

            if (r < 1)
                e->type = 0;
            else if (r < 3)
                e->type = 1;
            else
                e->type = 2;

            e->frame = 0;
            e->alive = true;
            e->next = *list;
            e->exploding = false;
            e->explosion_frame = 0;
            e->explosion_timer = 0;

            *list = e;
        }
    }
}




void update_enemies(Enemy *list, float delta_time) {
    static float enemy_step_timer = 0.0f;
    bool reached_edge = false;

    enemy_step_timer += delta_time;

    if (enemy_step_timer >= enemy_step_interval) {
        enemy_step_timer = 0.0f;

        Enemy *e = list;
        while (e) {
            if (e->alive) {
                // Verifica se vai sair da tela no próximo passo
                if ((moving_right && e->x + enemy_w * enemy_scale + 10 >= SCREEN_W) ||
                    (!moving_right && e->x - 10 <= 0)) {
                    reached_edge = true;
                    break;
                }
            }
            e = e->next;
        }

        e = list;
        while (e) {
            if (e->alive) {
                if (reached_edge) {
                    e->y += 10;
                } else {
                    e->x += moving_right ? enemy_dx : -enemy_dx;  // passo fixo
                }

                // Alterna sprite a cada passo
                e->frame = (e->frame + 1) % 2;
            }
            e = e->next;
        }

        if (reached_edge) {
            moving_right = !moving_right;
        }
    }
}



void draw_enemies(Enemy *list, float delta_time) {
    Enemy *e = list;
    while (e) {
        if (e->exploding) {
            e->explosion_timer += delta_time;

            if (e->explosion_timer >= 0.07f) {
                e->explosion_timer = 0;
                e->explosion_frame++;

                // Finaliza explosão
                if (e->explosion_frame >= 6) {
                    e->exploding = false;
                    e->alive = false;
                }
            }

            // Enquanto a explosão não terminou, desenha frame atual
            if (e->explosion_frame < 6) {
                ALLEGRO_BITMAP *expl_frame = enemy_explosion_frames[e->type][e->explosion_frame];

                if (expl_frame != NULL) {
                    al_draw_scaled_bitmap(
                        expl_frame, 0, 0,
                        al_get_bitmap_width(expl_frame), al_get_bitmap_height(expl_frame),
                        e->x, e->y,
                        enemy_w * enemy_scale,
                        enemy_h * enemy_scale,
                        0
                    );
                }
            }

        } else if (e->alive) {
            al_draw_scaled_bitmap(
                enemy_sprites[e->type][e->frame],
                0, 0,
                al_get_bitmap_width(enemy_sprites[e->type][e->frame]), al_get_bitmap_height(enemy_sprites[e->type][e->frame]),
                e->x, e->y,
                enemy_w * enemy_scale,
                enemy_h * enemy_scale,
                0
            );
        }

        e = e->next;
    }
}




void check_bullet_collision(Shot **shot_list, Enemy *enemies) {
    Shot *s = *shot_list;
    while (s) {
        Enemy *e = enemies;
        while (e) {
            if (e->alive) {
                int enemy_w_px = al_get_bitmap_width(enemy_sprites[e->type][e->frame]) * enemy_scale;
                int enemy_h_px = al_get_bitmap_height(enemy_sprites[e->type][e->frame]) * enemy_scale;


                int shot_w = 12;
                int shot_h = 30;

                bool collided = !(s->x + 12 < e->x ||
                                  s->x > e->x + enemy_w_px ||
                                  s->y + 30 < e->y ||
                                  s->y > e->y + enemy_h_px);


                if (collided) {
                    e->exploding = true;
                    e->explosion_frame = 0;
                    e->explosion_timer = 0.0f;

                    e->alive = false;
                      
                    s->y = -10; // remove o tiro
                    al_play_sample(sfx_boom, 1.2, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, NULL);

                    break;
                }
            }
            e = e->next;
        }
        s = s->next;
    }
}
void add_enemy_shot(float x, float y) {
    EnemyShot *new_shot = malloc(sizeof(EnemyShot));
    if (!new_shot) return;

    new_shot->x = x;
    new_shot->y = y;
    new_shot->next = enemy_shots;
    enemy_shots = new_shot;
}
int count_alive_enemies(Enemy *list) {
    int count = 0;
    while (list) {
        if (list->alive)
            count++;
        list = list->next;
    }
    return count;
}

void update_enemy_shots() {
    EnemyShot *current = enemy_shots;
    EnemyShot *prev = NULL;
    int total_enemies = rows * cols;
    int alive = count_alive_enemies(enemy_list);
    float percent_alive = (float)alive / total_enemies;

    while (current) {

        if (percent_alive >= 0.5)
        {
            current->y += 6;  // velocidade
        }
        if (percent_alive < 0.5 && percent_alive >= 0.2)
        {
            current->y += 7;  // velocidade
        }
        if (percent_alive < 0.2 && alive > 1 )
        {
            current->y += 10;  // velocidade
        }
        if ( alive == 1 )
        {
            current->y += 14;  // velocidade
        }
        

        if (current->y > SCREEN_H) {
            // remove
            if (prev == NULL) {
                enemy_shots = current->next;
                free(current);
                current = enemy_shots;
            } else {
                prev->next = current->next;
                free(current);
                current = prev->next;
            }
        } else {
            prev = current;
            current = current->next;
        }
    }
}

void draw_enemy_shots() {
    EnemyShot *s = enemy_shots;
    while (s) {
        int bullet_w = al_get_bitmap_width(enemy_bullet_sprite);
        int bullet_h = al_get_bitmap_height(enemy_bullet_sprite);
        float scale_factor = 2.5;

        al_draw_scaled_bitmap(enemy_bullet_sprite,
            0, 0,
            bullet_w, bullet_h,
            s->x - (bullet_w * scale_factor) / 2,  // centraliza o sprite
            s->y,
            bullet_w * scale_factor,
            bullet_h * scale_factor,
            0
        );

        s = s->next;
    }
}


void get_frontline_enemies(Enemy *list, Enemy *frontline[MAX_COLS]) {
    for (int i = 0; i < MAX_COLS; i++) frontline[i] = NULL;

    Enemy *e = list;
    while (e) {
        if (!e->alive) {
            e = e->next;
            continue;
        }

        int col = (int)((e->x - 100) / COL_WIDTH);  // mesma lógica usada na criação
        if (col >= 0 && col < MAX_COLS) {
            if (frontline[col] == NULL || e->y > frontline[col]->y) {
                frontline[col] = e;
            }
        }

        e = e->next;
    }
}




bool check_enemy_shot_collision_with_player(EnemyShot **list, float player_x, float player_y, float player_w, float player_h, float scale) {
    EnemyShot *current = *list;
    EnemyShot *prev = NULL;

    int scaled_w = player_w * scale;
    int scaled_h = player_h * scale;

    int bullet_w = al_get_bitmap_width(enemy_bullet_sprite);
    int bullet_h = al_get_bitmap_height(enemy_bullet_sprite);
    float scale_factor = 2.5;
    int scaled_bullet_w = bullet_w * scale_factor;
    int scaled_bullet_h = bullet_h * scale_factor;

    while (current) {
        bool collided = !(player_x + scaled_w < current->x ||
                          player_x > current->x + scaled_bullet_w ||
                          player_y + scaled_h < current->y ||
                          player_y > current->y + scaled_bullet_h);

        if (collided) {
            // Remove o tiro
            if (prev == NULL) {
                *list = current->next;
                free(current);
                current = *list;
            } else {
                prev->next = current->next;
                free(current);
                current = prev->next;
            }
            return true;  // Colisão detectada
        }

        prev = current;
        current = current->next;
    }

    return false;
}



bool check_game_over(Enemy *list, float player_y) {
    Enemy *e = list;

    // Garanta que player_w, player_h, scale e x estejam acessíveis globalmente ou passem como parâmetro
    int player_real_w = player_w * scale;
    int player_real_h = player_h * scale;

    while (e) {
        if (e->alive) {
            int enemy_real_w = al_get_bitmap_width(enemy_sprites[e->type][e->frame]) * enemy_scale;
            int enemy_real_h = al_get_bitmap_height(enemy_sprites[e->type][e->frame]) * enemy_scale;

            // Verifica se o inimigo chegou no chão
            if (e->y + enemy_real_h >= SCREEN_H) return true;

            // Verifica colisão com a nave (colisão retangular exata)
            bool collided = !(x + player_real_w < e->x ||     // Nave totalmente à esquerda do inimigo
                              x > e->x + enemy_real_w ||       // Nave totalmente à direita do inimigo
                              player_y + player_real_h < e->y || // Nave totalmente acima do inimigo
                              player_y > e->y + enemy_real_h);   // Nave totalmente abaixo do inimigo

            if (collided) return true;
        }
        e = e->next;
    }
    return false;
}



int main(void) {
    const float FPS = 60.0;

    srand(time(NULL));

    float speed = 6.0;
    bool idle = false;
    bool left_key = false;
    bool right_key = false;
    bool space_key = false;
    const float time_per_frame = 0.10;
    int current_frame = 0;
    float frame_time = 0;
    float shoot_cooldown = 1.0;
    float shoot_timer = 0.0;
    float backg_y = 0, backg_speed = 2.0;
    bool knockback_active = false;
    int knockback_frame = 0;
    float knockback_time = 0;
    const float knockback_duration = 0.3;
    const float knockback_frame_time = knockback_duration / 4;





    Shot *shot_list = NULL;

    al_init(); al_init_image_addon(); al_init_primitives_addon();
    al_install_keyboard(); al_install_audio();
    al_init_acodec_addon();
    al_reserve_samples(7);
    al_init_font_addon();
    al_init_ttf_addon();

    sfx_button = al_load_sample("sfx_button.ogg"); 
    if (!sfx_button) {
        fprintf(stderr, "Erro ao carregar som do botao.\n");
        return -1;
    }
    sfx_shot = al_load_sample("shotsfx.ogg"); 
    if (!sfx_shot) {
        fprintf(stderr, "Erro ao carregar som do tiro.\n");
        return -1;
    }
    sfx_boom = al_load_sample("boomsfx.ogg"); 
    if (!sfx_boom) {
        fprintf(stderr, "Erro ao carregar som do tiro.\n");
        return -1;
    }
    musica1 = al_load_sample("SoundTrack1.ogg");
    if (!musica1) return -1;

    musica2 = al_load_sample("SoundTrack2.ogg");
    if (!musica2) return -1;
    
    musica2_instance = al_create_sample_instance(musica2);
    al_attach_sample_instance_to_mixer(musica2_instance, al_get_default_mixer());

    musica2_1 = al_load_sample("SoundTrack2.1.ogg");
    if (!musica2_1) return -1;
    
    musica2_1_instance = al_create_sample_instance(musica2_1);
    al_attach_sample_instance_to_mixer(musica2_1_instance, al_get_default_mixer());

    musica2_2 = al_load_sample("SoundTrack2.2.ogg");
    if (!musica2_2) return -1;
    
    musica2_2_instance = al_create_sample_instance(musica2_2);
    al_attach_sample_instance_to_mixer(musica2_2_instance, al_get_default_mixer());


    display = al_create_display(SCREEN_W, SCREEN_H);
    if (!display) return -1;

    background = al_load_bitmap("stars_background.png");
    if (!background) return -1;

    interface_Move = al_load_bitmap("interface_Move.png");
    interface_SPACE = al_load_bitmap("interface_SPACE.png");

    if (!interface_Move || !interface_SPACE) {
    fprintf(stderr, "Erro ao carregar os botões.\n");
    return -1;
}

    player_bullet_frames[0] = al_load_bitmap("bullet1.png");
    player_bullet_frames[1] = al_load_bitmap("bullet2.png");
    player_bullet_frames[2] = al_load_bitmap("bullet3.png");
    player_bullet_frames[3] = al_load_bitmap("bullet4.png");

    enemy_bullet_sprite = al_load_bitmap("enemy_bullet.png");
    if (!enemy_bullet_sprite) {
    fprintf(stderr, "Erro ao carregar o sprite do tiro inimigo.\n");
    return -1;
}


    player_frames[0] = al_load_bitmap("spaceship1.png");
    player_frames[1] = al_load_bitmap("spaceship2.png");
    player_frames[2] = al_load_bitmap("spaceship3.png");
    player_frames[3] = al_load_bitmap("spaceship4.png");

    player_left_frames[0] = al_load_bitmap("spaceship5.png");
    player_left_frames[1] = al_load_bitmap("spaceship6.png");
    player_left_frames[2] = al_load_bitmap("spaceship7.png");
    player_left_frames[3] = al_load_bitmap("spaceship8.png");

    player_right_frames[0] = al_load_bitmap("spaceship9.png");
    player_right_frames[1] = al_load_bitmap("spaceship10.png");
    player_right_frames[2] = al_load_bitmap("spaceship11.png");
    player_right_frames[3] = al_load_bitmap("spaceship12.png");

    // Knockback padrão 
    player_knockback_frames[0] = al_load_bitmap("knockback1.png");
    player_knockback_frames[1] = al_load_bitmap("knockback2.png");
    player_knockback_frames[2] = al_load_bitmap("knockback3.png");
    player_knockback_frames[3] = al_load_bitmap("knockback4.png");

    // Knockback para esquerda
    player_knockback_left_frames[0] = al_load_bitmap("knockback_left1.png");
    player_knockback_left_frames[1] = al_load_bitmap("knockback_left2.png");
    player_knockback_left_frames[2] = al_load_bitmap("knockback_left3.png");
    player_knockback_left_frames[3] = al_load_bitmap("knockback_left4.png");

    // Knockback para direita
    player_knockback_right_frames[0] = al_load_bitmap("knockback_right1.png");
    player_knockback_right_frames[1] = al_load_bitmap("knockback_right2.png");
    player_knockback_right_frames[2] = al_load_bitmap("knockback_right3.png");
    player_knockback_right_frames[3] = al_load_bitmap("knockback_right4.png");


    enemy_sprites[0][0] = al_load_bitmap("enemy_purple1.png");
    enemy_sprites[0][1] = al_load_bitmap("enemy_purple2.png");
    enemy_sprites[1][0] = al_load_bitmap("enemy_gray1.png");
    enemy_sprites[1][1] = al_load_bitmap("enemy_gray2.png");
    enemy_sprites[2][0] = al_load_bitmap("enemy_green1.png");
    enemy_sprites[2][1] = al_load_bitmap("enemy_green2.png");

        char path[256];

    // Explosões roxas
    for (int i = 0; i < 6; i++) {
        sprintf(path, "enemy1_explosion%d.png", i + 1);
        enemy_explosion_frames[0][i] = al_load_bitmap(path);
        if (!enemy_explosion_frames[0][i]) {
        printf("Erro ao carregar enemy1_explosion%d.png\n", i+1);
}

    }

    // Explosões cinzas
    for (int i = 0; i < 6; i++) {
        sprintf(path, "enemygray_explosion%d.png", i + 1);
        enemy_explosion_frames[1][i] = al_load_bitmap(path);
    }

    // Explosões verdes
    for (int i = 0; i < 6; i++) {
        sprintf(path, "enemypurple_explosion%d.png", i + 1);
        enemy_explosion_frames[2][i] = al_load_bitmap(path);
    }




    create_enemy_group(&enemy_list);

    player_w = al_get_bitmap_width(player_frames[0]);
    player_h = al_get_bitmap_height(player_frames[0]);


x = (SCREEN_W - player_w * scale) / 2;
y = SCREEN_H - player_h * scale - 100;  // 30 é margem inferior opcional
    int direction = 1;

    event_queue = al_create_event_queue();
    timer = al_create_timer(1.0 / FPS);
    al_register_event_source(event_queue, al_get_keyboard_event_source());
    al_register_event_source(event_queue, al_get_display_event_source(display));
    al_register_event_source(event_queue, al_get_timer_event_source(timer));
    al_start_timer(timer);


    // Tela inicial - Menu de início
bool esperando_inicio = true;
bool sair = false;
float musica2_gain = 0.0;
bool fade_in_done = false;
float blink_timer = 0.0f;
bool show_text = true;


ALLEGRO_EVENT evento;

al_play_sample(musica1, 0.9, 0.0, 1.0, ALLEGRO_PLAYMODE_LOOP, &musica1_id);
while (esperando_inicio) {
    ALLEGRO_EVENT evento;
    al_wait_for_event(event_queue, &evento);

    if (evento.type == ALLEGRO_EVENT_DISPLAY_CLOSE) {
        esperando_inicio = false;
        sair = true;
    } else if (evento.type == ALLEGRO_EVENT_KEY_DOWN && evento.keyboard.keycode == ALLEGRO_KEY_ENTER) {
        al_play_sample(sfx_button, 2.8, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, NULL);
        al_stop_sample(&musica1_id);
        al_set_sample_instance_gain(musica2_instance, 0.0); // começa com volume 0
        al_set_sample_instance_playmode(musica2_instance, ALLEGRO_PLAYMODE_LOOP);
        al_play_sample_instance(musica2_instance);


        esperando_inicio = false;
        game_started = true;
    } else if (evento.type == ALLEGRO_EVENT_TIMER) {
        // Atualiza fundo animado
        backg_y += backg_speed;
        if (backg_y >= SCREEN_H) backg_y = 0;

        // Piscar o texto
        blink_timer += 1.0 / FPS;
        if (blink_timer >= 0.5) {
            blink_timer = 0;
            show_text = !show_text;
        }

        frame_time += 1.0 / FPS;
        if (frame_time >= time_per_frame) {
            frame_time = 0;
            current_frame = (current_frame + 1) % 4;
        }


        // Desenha fundo animado
        al_clear_to_color(al_map_rgb(0, 0, 0));
        al_draw_scaled_bitmap(background, 0, 0,
            al_get_bitmap_width(background), al_get_bitmap_height(background),
            0, backg_y, SCREEN_W, SCREEN_H, 0);
        al_draw_scaled_bitmap(background, 0, 0,
            al_get_bitmap_width(background), al_get_bitmap_height(background),
            0, backg_y - SCREEN_H, SCREEN_W, SCREEN_H, 0);

        // Desenha a nave parada no centro
        al_draw_scaled_bitmap(player_frames[current_frame], 0, 0, player_w, player_h,
            x, y, player_w * scale, player_h * scale, 0);

        int w_interface_Move = al_get_bitmap_width(interface_Move);
        int h_interface_Move = al_get_bitmap_height(interface_Move);
        float scale_interface = 1.70;
        al_draw_scaled_bitmap(
            interface_Move,
            0, 0,                                           // origem do recorte (bitmap completo)
            w_interface_Move, h_interface_Move,         // tamanho original
            SCREEN_W - 1347, 595,                             // posição na tela
            w_interface_Move * scale_interface,                    // nova largura
            h_interface_Move * scale_interface,                    // nova altura
            0                                               // flags
        );

        int w_interface_SPACE = al_get_bitmap_width(interface_SPACE);
        int h_interface_SPACE = al_get_bitmap_height(interface_SPACE);

        al_draw_scaled_bitmap(
            interface_SPACE,
            0, 0,                                           // origem do recorte (bitmap completo)
            w_interface_SPACE, h_interface_SPACE,         // tamanho original
            SCREEN_W - 1245, 627,                             // posição na tela
            w_interface_SPACE * scale_interface,                    // nova largura
            h_interface_SPACE * scale_interface,                    // nova altura
            0                                               // flags
        );

        // Escreve texto piscando
        if (show_text) {
            ALLEGRO_FONT *font = al_create_builtin_font();
            al_draw_text(font, al_map_rgb(255, 255, 255), SCREEN_W / 2, SCREEN_H / 2,
                         ALLEGRO_ALIGN_CENTER, "APERTE ENTER PARA INICIAR");
            al_destroy_font(font);
        }

        al_flip_display();

    }

}



   
    while (!sair) {
        ALLEGRO_EVENT ev;
        al_wait_for_event(event_queue, &ev);

        if (ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE) {
            sair = true;
        } else if (ev.type == ALLEGRO_EVENT_KEY_DOWN) {
            if (ev.keyboard.keycode == ALLEGRO_KEY_LEFT) left_key = true;
            if (ev.keyboard.keycode == ALLEGRO_KEY_RIGHT) right_key = true;
            if (ev.keyboard.keycode == ALLEGRO_KEY_SPACE && shoot_timer <= 0.0 && shot_list == NULL) {
                add_shot(x, y, player_w, scale, &shot_list);
                knockback_active = true;
                knockback_frame = 0;
                knockback_time = 0;
                shoot_timer = shoot_cooldown;

                al_play_sample(sfx_shot, 1.1, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, NULL);
            }

        } else if (ev.type == ALLEGRO_EVENT_KEY_UP) {
            if (ev.keyboard.keycode == ALLEGRO_KEY_LEFT) left_key = false;
            if (ev.keyboard.keycode == ALLEGRO_KEY_RIGHT) right_key = false;
            if (ev.keyboard.keycode == ALLEGRO_KEY_SPACE) space_key = false;
        } else if (ev.type == ALLEGRO_EVENT_TIMER) {
        
        if (!fade_in_done) {
            musica2_gain += 0.01; // ajuste a velocidade do fade aqui
            if (musica2_gain >= 0.9) {
                musica2_gain = 0.9;
                fade_in_done = true;
            }
            al_set_sample_instance_gain(musica2_instance, musica2_gain);
        }



        float delta_time = 1.0 / FPS;

        int total_enemies = rows * cols;
        int alive = count_alive_enemies(enemy_list);
        float percent_alive = (float)alive / total_enemies;
        float factor = 1.0f - pow(percent_alive,2); 
        enemy_step_interval = 0.3f - factor * 0.2f;
 
        float base_speed = 5.0f;
        
        if (percent_alive >= 0.5)
        {
            enemy_dx = base_speed + 5 * factor;
        }
        if (percent_alive < 0.5 && percent_alive >= 0.2)
        {   
            enemy_dx = base_speed + 7 * factor;
            al_stop_sample_instance(musica2_instance); // para a atual
            al_set_sample_instance_gain(musica2_1_instance, 1.0);
            al_set_sample_instance_playmode(musica2_1_instance, ALLEGRO_PLAYMODE_LOOP);
            al_play_sample_instance(musica2_1_instance); // toca a nova
        }
        if (percent_alive < 0.2 && percent_alive >= 0.1)
        {
            enemy_dx = base_speed + 10 * factor;
        }
        if (percent_alive < 0.1 && alive > 1)
        {   
            enemy_dx = base_speed + 20 * factor;
            al_stop_sample_instance(musica2_1_instance);
            al_set_sample_instance_gain(musica2_2_instance, 1.0); // começa com volume 0
            al_set_sample_instance_playmode(musica2_2_instance, ALLEGRO_PLAYMODE_LOOP);
            al_play_sample_instance(musica2_2_instance);
        }
        if (alive == 1)
        {
            enemy_dx = base_speed + 40 * factor;
        }     

        enemy_anim_interval = 0.5f - (enemy_dx - base_speed) * 0.03f;
        if (enemy_anim_interval < 0.05f) enemy_anim_interval = 0.05f;

        static float enemy_shot_timer = 0.0f;
        enemy_shot_timer += delta_time;
        if (enemy_shot_timer >= 0.5f) {  // ajuste o tempo de intervalo
            enemy_shot_timer = 0;

            Enemy *frontline[MAX_COLS];
            get_frontline_enemies(enemy_list, frontline);

            if (enemy_shots == NULL) {
                int col = rand() % MAX_COLS;
                if (frontline[col]) {
                    add_enemy_shot(frontline[col]->x + (enemy_w * enemy_scale) / 2,
                                   frontline[col]->y + (enemy_h * enemy_scale));
                }
            }

        }
            update_enemy_shots();


            check_bullet_collision(&shot_list, enemy_list);


            enemy_move_timer += delta_time;
            if (enemy_move_timer >= enemy_move_interval) {
                enemy_move_timer = 0.0f;

                // move os inimigos "em pulos"
                Enemy *e = enemy_list;
                bool reached_edge = false;

                while (e) {
                    if (e->alive) {
                        float next_x = e->x + (moving_right ? enemy_dx : -enemy_dx);
                        if ((next_x > SCREEN_W - enemy_w * enemy_scale) || (next_x < 0)) {
                            reached_edge = true;
                            break;
                        }
                    }
                    e = e->next;
                }

                
            }

            
            update_enemies(enemy_list, delta_time);
            if (check_game_over(enemy_list, y)) sair = true;
            if (check_enemy_shot_collision_with_player(&enemy_shots, x, y, player_w, player_h, scale)) {
                sair = true; 
            }

            if (shoot_timer > 0.0) shoot_timer -= 1.0 / FPS;

            if (knockback_active) {
                knockback_time += 1.0 / FPS;
                if (knockback_time >= knockback_duration)
                    knockback_active = false;
                else {
                    knockback_frame = (int)(knockback_time / knockback_frame_time);
                    if (knockback_frame > 3) knockback_frame = 3;
                }
            }

            backg_y += backg_speed;
            if (backg_y >= SCREEN_H) backg_y = 0;

            idle = false;
            if (left_key) {
                x -= speed;
                idle = true;
                direction = -1;
            }
            if (right_key) {
                x += speed;
                idle = true;
                direction = 1;
            }
            if (!right_key && !left_key) {
               
                idle = false;
                direction = 0;
            }

            frame_time += 1.0 / FPS;
            if (frame_time >= time_per_frame) {
                frame_time = 0;
                current_frame = (current_frame + 1) % 4;
            }

            if (x < 0) x = 0;
            if (x > SCREEN_W - player_w * scale) x = SCREEN_W - player_w * scale;

            al_clear_to_color(al_map_rgb(0, 0, 0));
            al_draw_scaled_bitmap(background, 0, 0, al_get_bitmap_width(background), al_get_bitmap_height(background), 0, backg_y, SCREEN_W, SCREEN_H, 0);
            al_draw_scaled_bitmap(background, 0, 0, al_get_bitmap_width(background), al_get_bitmap_height(background), 0, backg_y - SCREEN_H, SCREEN_W, SCREEN_H, 0);

            if (knockback_active) {
                ALLEGRO_BITMAP *kb_frame;
                if (direction == -1) {
                    kb_frame = player_knockback_left_frames[knockback_frame];
                } else if (direction == 1) {
                    kb_frame = player_knockback_right_frames[knockback_frame];
                } else {
                    kb_frame = player_knockback_frames[knockback_frame];
                }

                int kb_width = al_get_bitmap_width(kb_frame);
                int kb_height = al_get_bitmap_height(kb_frame);

                al_draw_scaled_bitmap(kb_frame,
                    0, 0,
                    kb_width, kb_height,
                    x, y,
                    kb_width * scale, kb_height * scale,
                    0
                );
            }

            else if (idle) {
                ALLEGRO_BITMAP *frame = direction == 1 ? player_right_frames[current_frame] : player_left_frames[current_frame];
                al_draw_scaled_bitmap(frame, 0, 0, player_w, player_h, x, y, player_w * scale, player_h * scale, 0);
            } else {
                al_draw_scaled_bitmap(player_frames[current_frame], 0, 0, player_w, player_h, x, y, player_w * scale, player_h * scale, 0);
            }

            update_shots(&shot_list);
            draw_shots(shot_list);
            draw_enemies(enemy_list,delta_time);
            draw_enemy_shots();


            al_flip_display();
        }
    }

    free_shots(&shot_list);

    for (int i = 0; i < 4; i++) {
        al_destroy_bitmap(player_knockback_frames[i]);
        al_destroy_bitmap(player_frames[i]);
        al_destroy_bitmap(player_left_frames[i]);
        al_destroy_bitmap(player_right_frames[i]);
    }

    for (int t = 0; t < 3; t++) {
        for (int i = 0; i < 6; i++) {
        al_destroy_bitmap(enemy_explosion_frames[t][i]);
        }
    }


    al_destroy_bitmap(background);
    al_destroy_timer(timer);
    al_destroy_event_queue(event_queue);
    al_destroy_display(display);
    al_destroy_sample(musica1);
    al_destroy_sample(musica2);
    al_destroy_sample(musica2_1);
    al_destroy_sample(musica2_2);
    al_destroy_sample(sfx_shot);
    al_destroy_sample(sfx_button);
    al_destroy_sample(sfx_boom);
    al_destroy_bitmap(enemy_bullet_sprite);



    return 0;
}