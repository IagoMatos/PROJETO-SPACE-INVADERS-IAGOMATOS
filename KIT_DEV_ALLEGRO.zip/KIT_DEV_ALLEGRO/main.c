#include <stdio.h>
#include <math.h>
#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/keyboard.h>
#include <allegro5/keycodes.h>
#include <allegro5/allegro_audio.h>
#include <allegro5/allegro_acodec.h>
#include <stdbool.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <time.h>


#define MAX_COLS 10
#define COL_WIDTH 36
#define FPS 60.0


int g_high_score = 0;
const char *HIGH_SCORE_FILE = "highscore.txt";


const float ENEMY_GAME_OVER_LINE_Y = 680.0f;


float g_enemy_speed_multiplier = 1.0f;
const float SPEED_INCREASE_FACTOR = 1.25f;


int g_current_round = 1;

ALLEGRO_DISPLAY *g_display = NULL;
ALLEGRO_EVENT_QUEUE *g_event_queue = NULL;
ALLEGRO_TIMER *g_timer = NULL;

ALLEGRO_BITMAP *g_background = NULL;
ALLEGRO_BITMAP *g_player_frames[4];
ALLEGRO_BITMAP *g_player_left_frames[4];
ALLEGRO_BITMAP *g_player_right_frames[4];
ALLEGRO_BITMAP *g_player_knockback_frames[4];
ALLEGRO_BITMAP *g_player_knockback_left_frames[4];
ALLEGRO_BITMAP *g_player_knockback_right_frames[4];
ALLEGRO_BITMAP *g_enemy_explosion_frames[3][6];
ALLEGRO_BITMAP *g_player_explosion_frames[6];
ALLEGRO_BITMAP *g_enemy_bullet_sprite = NULL;
ALLEGRO_BITMAP *g_interface_Move = NULL;
ALLEGRO_BITMAP *g_interface_SPACE = NULL;
ALLEGRO_BITMAP *g_logo = NULL;
ALLEGRO_BITMAP *g_enemy_sprites[3][2];
ALLEGRO_BITMAP *g_player_bullet_frames[4];

ALLEGRO_SAMPLE_ID g_musica1_id;
ALLEGRO_SAMPLE_INSTANCE *g_musica2_instance = NULL;
ALLEGRO_SAMPLE_INSTANCE *g_musica2_1_instance = NULL;
ALLEGRO_SAMPLE_INSTANCE *g_musica2_2_instance = NULL;
ALLEGRO_SAMPLE *g_musica1 = NULL;
ALLEGRO_SAMPLE *g_musica2 = NULL;
ALLEGRO_SAMPLE *g_musica2_1 = NULL;
ALLEGRO_SAMPLE *g_musica2_2 = NULL;
ALLEGRO_SAMPLE *g_sfx_shot = NULL;
ALLEGRO_SAMPLE *g_sfx_button = NULL;
ALLEGRO_SAMPLE *g_sfx_boom = NULL;

ALLEGRO_SAMPLE_INSTANCE *current_game_music_instance = NULL;

ALLEGRO_FONT *g_game_font = NULL;
ALLEGRO_FONT *g_menu_font = NULL;

const int SCREEN_W = 1024;
const int SCREEN_H = 768;

float g_player_x = 0;
float g_player_y = 0;
int g_player_w = 0;
int g_player_h = 0;
float g_player_scale = 0.2;

int g_score = 0;
bool g_player_exploding = false;
int g_player_explosion_frame = 0;
float g_player_explosion_timer = 0.0f;

float g_enemy_scale = 2.8;
int g_enemy_w = 16;
int g_enemy_h = 16;
float g_enemy_dx = 2.0;
bool g_moving_right = true;
float g_enemy_step_interval = 0.3f;

int g_rows = 5, g_cols = 10;
int g_start_x;

typedef enum GameState {
    MENU,
    PLAYING,
    PAUSED,
    ROUND_TRANSITION,
    GAME_OVER
} GameState;

GameState current_game_state = MENU;

typedef struct Shot {
    float x, y;
    struct Shot *next;
    int frame;
    bool stabilized;
} Shot;

typedef struct Enemy {
    float x, y;
    int type;
    int frame;
    bool alive;
    bool exploding;
    int explosion_frame;
    float explosion_timer;
    struct Enemy *next;
} Enemy;

typedef struct EnemyShot {
    float x, y;
    struct EnemyShot *next;
} EnemyShot;

Shot *g_shot_list = NULL;
Enemy *g_enemy_list = NULL;
EnemyShot *g_enemy_shots = NULL;


void load_high_score() {
    FILE *file = fopen(HIGH_SCORE_FILE, "r");
    if (file) {
        fscanf(file, "%d", &g_high_score);
        fclose(file);
    } else {
        g_high_score = 0;
    }
}

void save_high_score() {
    FILE *file = fopen(HIGH_SCORE_FILE, "w");
    if (file) {
        fprintf(file, "%d", g_high_score);
        fclose(file);
    } else {
        fprintf(stderr, "Erro ao salvar high score.\n");
    }
}

void check_and_save_high_score() {
    if (g_score > g_high_score) {
        g_high_score = g_score;
        save_high_score();
    }
}

void free_shots(Shot **list) {
    while (*list != NULL) {
        Shot *tmp = *list;
        *list = (*list)->next;
        free(tmp);
    }
}

void add_shot(float x, float y, float player_w, float scale, Shot **list) {
    Shot *new_shot = malloc(sizeof(Shot));
    if (!new_shot) return;

    new_shot->x = (x + (player_w * scale) / 2 - 2);
    new_shot->y = y - 14;
    new_shot->frame = 0;
    new_shot->stabilized = false;
    new_shot->next = *list;
    *list = new_shot;
}

void update_shots(Shot **list) {
    Shot *current = *list;
    Shot *prev = NULL;

    while (current != NULL) {
        current->y -= 7;
        if (!current->stabilized) {
            current->frame++;
            if (current->frame >= 3) {
                current->frame = 3;
                current->stabilized = true;
            }
        }
        if (current->y < 0) {
            Shot *to_remove = current;
            if (prev == NULL) {
                *list = current->next;
                current = *list;
            } else {
                prev->next = current->next;
                current = current->next;
            }
            free(to_remove);
        } else {
            prev = current;
            current = current->next;
        }
    }
}

void draw_shots(Shot *list) {
    while (list != NULL) {
        ALLEGRO_BITMAP *bmp = list->stabilized ? g_player_bullet_frames[3] : g_player_bullet_frames[list->frame];
        al_draw_scaled_bitmap(bmp, 0, 0,
        al_get_bitmap_width(bmp),
        al_get_bitmap_height(bmp),
        list->x, list->y, 12, 30, 0);
        list = list->next;
    }
}

void create_enemy_group(Enemy **list) {
    int spacing_x = COL_WIDTH ;
    int spacing_y = 37;
    int enemy_w_orig = 16;

    float enemy_width_scaled = enemy_w_orig * g_enemy_scale;
    int total_width = (g_cols * enemy_width_scaled) + ((g_cols - 1) * spacing_x);
    g_start_x = (SCREEN_W - total_width) / 2;
    int start_y = 50;


    for (int r = 0; r < g_rows; r++) {
        for (int c = 0; c < g_cols; c++) {
            Enemy *e = malloc(sizeof(Enemy));
            e->x = g_start_x + c * (enemy_width_scaled + spacing_x);
            e->y = start_y + r * (enemy_w_orig * g_enemy_scale + spacing_y);

            if (r < 1)
                e->type = 0;
            else if (r < 3)
                e->type = 1;
            else
                e->type = 2;

            e->frame = 0;
            e->alive = true;
            e->next = *list;
            e->exploding = false;
            e->explosion_frame = 0;
            e->explosion_timer = 0;

            *list = e;
        }
    }
}

void update_enemies(Enemy *list, float delta_time) {
    static float enemy_step_timer = 0.0f;
    bool reached_edge = false;

    enemy_step_timer += delta_time;

    if (enemy_step_timer >= g_enemy_step_interval) {
        enemy_step_timer = 0.0f;

        Enemy *e = list;
        while (e) {
            if (e->alive) {
                if ((g_moving_right && e->x + g_enemy_w * g_enemy_scale + g_enemy_dx >= SCREEN_W) ||
                    (!g_moving_right && e->x - g_enemy_dx <= 0)) {
                    reached_edge = true;
                    break;
                }
            }
            e = e->next;
        }

        e = list;
        while (e) {
            if (e->alive) {
                if (reached_edge) {
                    e->y += 20;
                } else {
                    e->x += g_moving_right ? g_enemy_dx : -g_enemy_dx;
                }

                e->frame = (e->frame + 1) % 2;
            }
            e = e->next;
        }

        if (reached_edge) {
            g_moving_right = !g_moving_right;
        }
    }
}

void draw_enemies(Enemy *list, float delta_time) {
    Enemy *e = list;
    while (e) {
        if (e->exploding) {
            e->explosion_timer += delta_time;

            if (e->explosion_timer >= 0.07f) {
                e->explosion_timer = 0;
                e->explosion_frame++;

                if (e->explosion_frame >= 6) {
                    e->exploding = false;
                    e->alive = false;
                }
            }

            if (e->explosion_frame < 6) {
                ALLEGRO_BITMAP *expl_frame = g_enemy_explosion_frames[e->type][e->explosion_frame];

                if (expl_frame != NULL) {
                    al_draw_scaled_bitmap(
                        expl_frame, 0, 0,
                        al_get_bitmap_width(expl_frame), al_get_bitmap_height(expl_frame),
                        e->x, e->y,
                        g_enemy_w * g_enemy_scale,
                        g_enemy_h * g_enemy_scale,
                        0
                    );
                }
            }

        } else if (e->alive) {
            al_draw_scaled_bitmap(
                g_enemy_sprites[e->type][e->frame],
                0, 0,
                al_get_bitmap_width(g_enemy_sprites[e->type][e->frame]), al_get_bitmap_height(g_enemy_sprites[e->type][e->frame]),
                e->x, e->y,
                g_enemy_w * g_enemy_scale,
                g_enemy_h * g_enemy_scale,
                0
            );
        }

        e = e->next;
    }
}

void check_bullet_collision(Shot **shot_list, Enemy *enemies) {
    Shot *s = *shot_list;
    while (s) {
        Enemy *e = enemies;
        while (e) {
            if (e->alive && !e->exploding) {
                int enemy_w_px = al_get_bitmap_width(g_enemy_sprites[e->type][e->frame]) * g_enemy_scale;
                int enemy_h_px = al_get_bitmap_height(g_enemy_sprites[e->type][e->frame]) * g_enemy_scale;

                bool collided = !(s->x + 6 < e->x ||
                                  s->x > e->x + enemy_w_px ||
                                  s->y + 15 < e->y ||
                                  s->y > e->y + enemy_h_px);

                if (collided) {
                    e->exploding = true;
                    e->explosion_frame = 0;
                    e->explosion_timer = 0.0f;

                    if (e->type == 0)      g_score += 30;
                    else if (e->type == 1) g_score += 20;
                    else if (e->type == 2) g_score += 10;

                    s->y = -10;
                    al_play_sample(g_sfx_boom, 1.2, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, NULL);
                    break;
                }
            }
            e = e->next;
        }
        s = s->next;
    }
}

void add_enemy_shot(float x, float y) {
    EnemyShot *new_shot = malloc(sizeof(EnemyShot));
    if (!new_shot) return;

    new_shot->x = x;
    new_shot->y = y;
    new_shot->next = g_enemy_shots;
    g_enemy_shots = new_shot;
}

int count_alive_enemies(Enemy *list) {
    int count = 0;
    while (list) {
        if (list->alive && !list->exploding)
            count++;
        list = list->next;
    }
    return count;
}

void update_enemy_shots() {
    EnemyShot *current = g_enemy_shots;
    EnemyShot *prev = NULL;
    int total_enemies = g_rows * g_cols;
    int alive = count_alive_enemies(g_enemy_list);
    float percent_alive = (float)alive / total_enemies;
    float shot_speed;

    if (percent_alive >= 0.5) {
        shot_speed = 5;
    } else if (percent_alive < 0.5 && percent_alive >= 0.2) {
        shot_speed = 6;
    } else if (percent_alive < 0.2 && alive > 1 ) {
        shot_speed = 7.5;
    } else if (alive == 1) {
        shot_speed = 10;
    } else {
        shot_speed = 0;
    }

    while (current) {
        current->y += shot_speed;

        if (current->y > SCREEN_H) {
            if (prev == NULL) {
                g_enemy_shots = current->next;
                free(current);
                current = g_enemy_shots;
            } else {
                prev->next = current->next;
                free(current);
                current = prev->next;
            }
        } else {
            prev = current;
            current = current->next;
        }
    }
}

void draw_enemy_shots() {
    EnemyShot *s = g_enemy_shots;
    while (s) {
        int bullet_w = al_get_bitmap_width(g_enemy_bullet_sprite);
        int bullet_h = al_get_bitmap_height(g_enemy_bullet_sprite);
        float scale_factor = 2.5;

        al_draw_scaled_bitmap(g_enemy_bullet_sprite,
            0, 0,
            bullet_w, bullet_h,
            s->x - (bullet_w * scale_factor) / 2,
            s->y,
            bullet_w * scale_factor,
            bullet_h * scale_factor,
            0
        );
        s = s->next;
    }
}

void get_frontline_enemies(Enemy *list, Enemy *frontline[MAX_COLS]) {
    for (int i = 0; i < MAX_COLS; i++) frontline[i] = NULL;

    Enemy *e = list;
    while (e) {
        if (!e->alive || e->exploding) {
            e = e->next;
            continue;
        }

        int col = (int)((e->x - g_start_x) / (g_enemy_w * g_enemy_scale + COL_WIDTH));
        if (col >= 0 && col < MAX_COLS) {
            if (frontline[col] == NULL || e->y > frontline[col]->y) {
                frontline[col] = e;
            }
        }
        e = e->next;
    }
}


bool check_enemy_shot_collision_with_player(EnemyShot **list, float player_x, float player_y, float player_w, float player_h, float scale) {
    EnemyShot *current = *list;
    EnemyShot *prev = NULL;

    int scaled_w = player_w * scale;
    int scaled_h = player_h * scale;

    int bullet_w = al_get_bitmap_width(g_enemy_bullet_sprite);
    int bullet_h = al_get_bitmap_height(g_enemy_bullet_sprite);
    float scale_factor = 2.5;
    int scaled_bullet_w = bullet_w * scale_factor;
    int scaled_bullet_h = bullet_h * scale_factor;

    while (current) {
        bool collided = !(player_x + scaled_w < current->x ||
                          player_x > current->x + scaled_bullet_w ||
                          player_y + scaled_h < current->y ||
                          player_y > current->y + scaled_bullet_h);

        if (collided) {
            if (prev == NULL) {
                *list = current->next;
                free(current);
                current = *list;
            } else {
                prev->next = current->next;
                free(current);
                current = prev->next;
            }
            al_play_sample(g_sfx_boom, 1.2, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, NULL);
            return true;
        }

        prev = current;
        current = current->next;
    }
    return false;
}

void reset_game_state();
void run_paused();
void run_round_transition();


void run_paused() {
    bool paused_screen_active = true;

    ALLEGRO_SAMPLE_INSTANCE *music_on_pause = current_game_music_instance;

    al_stop_timer(g_timer);

    if (music_on_pause != NULL) {
        al_stop_sample_instance(music_on_pause);
    }

    al_clear_to_color(al_map_rgb(0, 0, 0));
    al_draw_filled_rectangle(0, 0, SCREEN_W, SCREEN_H, al_map_rgba(0, 0, 0, 150));

    al_draw_text(g_game_font, al_map_rgb(255, 255, 255), SCREEN_W / 2, SCREEN_H / 2 - 40, ALLEGRO_ALIGN_CENTER, "PAUSADO");
    al_draw_text(g_game_font, al_map_rgb(200, 200, 200), SCREEN_W / 2, SCREEN_H / 2 + 10, ALLEGRO_ALIGN_CENTER, "Pressione P ou ESC para continuar");
    al_draw_text(g_game_font, al_map_rgb(200, 200, 200), SCREEN_W / 2, SCREEN_H / 2 + 30, ALLEGRO_ALIGN_CENTER, "Pressione M para voltar ao Menu");

    al_flip_display();

    while (paused_screen_active) {
        ALLEGRO_EVENT ev;
        al_wait_for_event(g_event_queue, &ev);

        if (ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE) {
            paused_screen_active = false;
            current_game_state = -1;
        } else if (ev.type == ALLEGRO_EVENT_KEY_DOWN) {
            if (ev.keyboard.keycode == ALLEGRO_KEY_P || ev.keyboard.keycode == ALLEGRO_KEY_ESCAPE) {
                al_play_sample(g_sfx_button, 2.8, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, NULL);
                paused_screen_active = false;
                current_game_state = PLAYING;
            } else if (ev.keyboard.keycode == ALLEGRO_KEY_M) {
                al_play_sample(g_sfx_button, 2.8, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, NULL);
                g_enemy_speed_multiplier = 1.0f;
                paused_screen_active = false;
                current_game_state = MENU;
            }
        }
    }

    al_start_timer(g_timer);

    if (music_on_pause != NULL) {
        al_play_sample_instance(music_on_pause);
    }
}

static int transition_current_player_frame = 0;
static float transition_player_frame_time = 0;
static bool transition_left_key = false;
static bool transition_right_key = false;
static int transition_player_direction = 0;


void run_round_transition() {
    bool transition_active = true;
    float transition_timer = 0.0f;
    const float TRANSITION_DURATION = 4.0f;
    float player_speed = 6.0;

    if (current_game_music_instance != NULL) {
        al_stop_sample_instance(current_game_music_instance);
        current_game_music_instance = NULL;
    }

    float backg_y = 0;

    transition_left_key = false;
    transition_right_key = false;
    transition_player_direction = 0;
    transition_current_player_frame = 0;
    transition_player_frame_time = 0;
 
    while (transition_active) {
        ALLEGRO_EVENT ev;
        al_wait_for_event(g_event_queue, &ev);

        if (ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE) {
            transition_active = false;
            current_game_state = -1;
        } else if (ev.type == ALLEGRO_EVENT_KEY_DOWN) {
            if (ev.keyboard.keycode == ALLEGRO_KEY_LEFT) transition_left_key = true;
            if (ev.keyboard.keycode == ALLEGRO_KEY_RIGHT) transition_right_key = true;
            if (ev.keyboard.keycode == ALLEGRO_KEY_ENTER) {
                transition_timer = TRANSITION_DURATION;
            }
        } else if (ev.type == ALLEGRO_EVENT_KEY_UP) {
            if (ev.keyboard.keycode == ALLEGRO_KEY_LEFT) transition_left_key = false;
            if (ev.keyboard.keycode == ALLEGRO_KEY_RIGHT) transition_right_key = false;
        }
        
        else if (ev.type == ALLEGRO_EVENT_TIMER) {
            float delta_time = 1.0f / FPS;

            transition_timer += delta_time;

            backg_y += 2.0;
            if (backg_y >= SCREEN_H) backg_y = 0;

            transition_player_direction = 0;
            if (transition_left_key) {
                g_player_x -= player_speed;
                transition_player_direction = -1;
            }
            if (transition_right_key) {
                g_player_x += player_speed;
                transition_player_direction = 1;
            }

            if (g_player_x < 0) g_player_x = 0;
            if (g_player_x > SCREEN_W - g_player_w * g_player_scale) g_player_x = SCREEN_W - g_player_w * g_player_scale;

            transition_player_frame_time += delta_time;
            if (transition_player_frame_time >= 0.10) {
                transition_player_frame_time = 0;
                transition_current_player_frame = (transition_current_player_frame + 1) % 4;
            }

            al_clear_to_color(al_map_rgb(0, 0, 0));
            al_draw_scaled_bitmap(g_background, 0, 0, al_get_bitmap_width(g_background), al_get_bitmap_height(g_background), 0, backg_y, SCREEN_W, SCREEN_H, 0);
            al_draw_scaled_bitmap(g_background, 0, 0, al_get_bitmap_width(g_background), al_get_bitmap_height(g_background), 0, backg_y - SCREEN_H, SCREEN_W, SCREEN_H, 0);

            ALLEGRO_BITMAP *player_bmp_to_draw;
            if (transition_player_direction == -1) {
                player_bmp_to_draw = g_player_left_frames[transition_current_player_frame];
            } else if (transition_player_direction == 1) {
                player_bmp_to_draw = g_player_right_frames[transition_current_player_frame];
            } else {
                player_bmp_to_draw = g_player_frames[transition_current_player_frame];
            }

            al_draw_scaled_bitmap(player_bmp_to_draw, 0, 0,
                                  al_get_bitmap_width(player_bmp_to_draw), al_get_bitmap_height(player_bmp_to_draw),
                                  g_player_x, g_player_y,
                                  g_player_w * g_player_scale, g_player_h * g_player_scale, 0);


            al_draw_text(g_menu_font, al_map_rgb(255, 255, 0), SCREEN_W / 2, SCREEN_H / 2 - 80, ALLEGRO_ALIGN_CENTER, "PARABENS!");

            char round_text[32];
            sprintf(round_text, "ROUND %d", g_current_round);
            al_draw_text(g_menu_font, al_map_rgb(255, 255, 255), SCREEN_W / 2, SCREEN_H / 2 - 30, ALLEGRO_ALIGN_CENTER, round_text);

            al_flip_display();

            if (transition_timer >= TRANSITION_DURATION) {
                transition_active = false;
                reset_game_state();
                current_game_state = PLAYING;
            }
        }
    }
}


bool check_game_over_conditions(Enemy *list, float player_y) {
    Enemy *e = list;

    int player_real_w = g_player_w * g_player_scale;
    int player_real_h = g_player_h * g_player_scale;

    while (e) {
        if (e->alive && !e->exploding) {
            int enemy_real_w = al_get_bitmap_width(g_enemy_sprites[e->type][e->frame]) * g_enemy_scale;
            int enemy_real_h = al_get_bitmap_height(g_enemy_sprites[e->type][e->frame]) * g_enemy_scale;

            if (e->y + enemy_real_h >= SCREEN_H - player_real_h - 10) return true;

            if (e->y + enemy_real_h >= ENEMY_GAME_OVER_LINE_Y) return true;

            bool collided = !(g_player_x + player_real_w < e->x ||
                              g_player_x > e->x + enemy_real_w ||
                              player_y + player_real_h < e->y ||
                              player_y > e->y + enemy_real_h);

            if (collided) return true;
        }
        e = e->next;
    }
    return false;
}

bool load_assets() {
    g_sfx_button = al_load_sample("sfx_button.ogg");
    if (!g_sfx_button) { fprintf(stderr, "Erro ao carregar sfx_button.ogg.\n"); return false; }
    g_sfx_shot = al_load_sample("shotsfx.ogg");
    if (!g_sfx_shot) { fprintf(stderr, "Erro ao carregar shotsfx.ogg.\n"); return false; }
    g_sfx_boom = al_load_sample("boomsfx.ogg");
    if (!g_sfx_boom) { fprintf(stderr, "Erro ao carregar boomsfx.ogg.\n"); return false; }

    g_musica1 = al_load_sample("SoundTrack1.ogg");
    if (!g_musica1) { fprintf(stderr, "Erro ao carregar SoundTrack1.ogg.\n"); return false; }
    g_musica2 = al_load_sample("SoundTrack2.ogg");
    if (!g_musica2) { fprintf(stderr, "Erro ao carregar SoundTrack2.ogg.\n"); return false; }
    g_musica2_1 = al_load_sample("SoundTrack2.1.ogg");
    if (!g_musica2_1) { fprintf(stderr, "Erro ao carregar SoundTrack2.1.ogg.\n"); return false; }
    g_musica2_2 = al_load_sample("SoundTrack2.2.ogg");
    if (!g_musica2_2) { fprintf(stderr, "Erro ao criar instancia da musica 2.2.\n"); return false; }

    g_musica2_instance = al_create_sample_instance(g_musica2);
    if (!g_musica2_instance) { fprintf(stderr, "Erro ao criar instancia da musica 2.\n"); return false; }
    al_attach_sample_instance_to_mixer(g_musica2_instance, al_get_default_mixer());

    g_musica2_1_instance = al_create_sample_instance(g_musica2_1);
    if (!g_musica2_1_instance) { fprintf(stderr, "Erro ao criar instancia da musica 2.1.\n"); return false; }
    al_attach_sample_instance_to_mixer(g_musica2_1_instance, al_get_default_mixer());

    g_musica2_2_instance = al_create_sample_instance(g_musica2_2);
    if (!g_musica2_2_instance) { fprintf(stderr, "Erro ao criar instancia da musica 2.2.\n"); return false; }
    al_attach_sample_instance_to_mixer(g_musica2_2_instance, al_get_default_mixer());

    g_background = al_load_bitmap("stars_background.png");
    if (!g_background) { fprintf(stderr, "Erro ao carregar stars_background.png.\n"); return false; }

    g_interface_Move = al_load_bitmap("interface_Move.png");
    g_interface_SPACE = al_load_bitmap("interface_SPACE.png");
    g_logo = al_load_bitmap("logo.png");
    if (!g_interface_Move || !g_interface_SPACE || !g_logo) { fprintf(stderr, "Erro ao carregar os botões de interface ou logo.\n"); return false; }

    g_player_bullet_frames[0] = al_load_bitmap("bullet1.png");
    g_player_bullet_frames[1] = al_load_bitmap("bullet2.png");
    g_player_bullet_frames[2] = al_load_bitmap("bullet3.png");
    g_player_bullet_frames[3] = al_load_bitmap("bullet4.png");
    for (int i = 0; i < 4; i++) if (!g_player_bullet_frames[i]) { fprintf(stderr, "Erro ao carregar bullet%d.png.\n", i+1); return false; }

    g_enemy_bullet_sprite = al_load_bitmap("enemy_bullet.png");
    if (!g_enemy_bullet_sprite) { fprintf(stderr, "Erro ao carregar enemy_bullet.png.\n"); return false; }

    g_player_frames[0] = al_load_bitmap("spaceship1.png");
    g_player_frames[1] = al_load_bitmap("spaceship2.png");
    g_player_frames[2] = al_load_bitmap("spaceship3.png");
    g_player_frames[3] = al_load_bitmap("spaceship4.png");
    for (int i = 0; i < 4; i++) if (!g_player_frames[i]) { fprintf(stderr, "Erro ao carregar spaceship%d.png.\n", i+1); return false; }

    g_player_left_frames[0] = al_load_bitmap("spaceship5.png");
    g_player_left_frames[1] = al_load_bitmap("spaceship6.png");
    g_player_left_frames[2] = al_load_bitmap("spaceship7.png");
    g_player_left_frames[3] = al_load_bitmap("spaceship8.png");
    for (int i = 0; i < 4; i++) if (!g_player_left_frames[i]) { fprintf(stderr, "Erro ao carregar spaceship%d.png.\n", i+5); return false; }

    g_player_right_frames[0] = al_load_bitmap("spaceship9.png");
    g_player_right_frames[1] = al_load_bitmap("spaceship10.png");
    g_player_right_frames[2] = al_load_bitmap("spaceship11.png");
    g_player_right_frames[3] = al_load_bitmap("spaceship12.png");
    for (int i = 0; i < 4; i++) if (!g_player_right_frames[i]) { fprintf(stderr, "Erro ao carregar spaceship%d.png.\n", i+9); return false; }

    g_player_knockback_frames[0] = al_load_bitmap("knockback1.png");
    g_player_knockback_frames[1] = al_load_bitmap("knockback2.png");
    g_player_knockback_frames[2] = al_load_bitmap("knockback3.png");
    g_player_knockback_frames[3] = al_load_bitmap("knockback4.png");
    for (int i = 0; i < 4; i++) if (!g_player_knockback_frames[i]) { fprintf(stderr, "Erro ao carregar knockback%d.png.\n", i+1); return false; }

    g_player_knockback_left_frames[0] = al_load_bitmap("knockback_left1.png");
    g_player_knockback_left_frames[1] = al_load_bitmap("knockback_left2.png");
    g_player_knockback_left_frames[2] = al_load_bitmap("knockback_left3.png");
    g_player_knockback_left_frames[3] = al_load_bitmap("knockback_left4.png");
    for (int i = 0; i < 4; i++) if (!g_player_knockback_left_frames[i]) { fprintf(stderr, "Erro ao carregar knockback_left%d.png.\n", i+1); return false; }

    g_player_knockback_right_frames[0] = al_load_bitmap("knockback_right1.png");
    g_player_knockback_right_frames[1] = al_load_bitmap("knockback_right2.png");
    g_player_knockback_right_frames[2] = al_load_bitmap("knockback_right3.png");
    g_player_knockback_right_frames[3] = al_load_bitmap("knockback_right4.png");
    for (int i = 0; i < 4; i++) if (!g_player_knockback_right_frames[i]) { fprintf(stderr, "Erro ao carregar knockback_right%d.png.\n", i+1); return false; }

    g_enemy_sprites[0][0] = al_load_bitmap("enemy_purple1.png");
    g_enemy_sprites[0][1] = al_load_bitmap("enemy_purple2.png");
    g_enemy_sprites[1][0] = al_load_bitmap("enemy_gray1.png");
    g_enemy_sprites[1][1] = al_load_bitmap("enemy_gray2.png");
    g_enemy_sprites[2][0] = al_load_bitmap("enemy_green1.png");
    g_enemy_sprites[2][1] = al_load_bitmap("enemy_green2.png");
    for (int i = 0; i < 2; i++) {
        if (!g_enemy_sprites[0][i]) { fprintf(stderr, "Erro ao carregar enemy_purple%d.png.\n", i+1); return false; }
        if (!g_enemy_sprites[1][i]) { fprintf(stderr, "Erro ao carregar enemy_gray%d.png.\n", i+1); return false; }
        if (!g_enemy_sprites[2][i]) { fprintf(stderr, "Erro ao carregar enemy_green%d.png.\n", i+1); return false; }
    }

    char path[256];
    for (int i = 0; i < 6; i++) {
        sprintf(path, "enemy1_explosion%d.png", i + 1);
        g_enemy_explosion_frames[0][i] = al_load_bitmap(path);
        if (!g_enemy_explosion_frames[0][i]) { printf("Erro ao carregar %s\n", path); return false; }
        sprintf(path, "enemygray_explosion%d.png", i + 1);
        g_enemy_explosion_frames[1][i] = al_load_bitmap(path);
        if (!g_enemy_explosion_frames[1][i]) { printf("Erro ao carregar %s\n", path); return false; }
        sprintf(path, "enemypurple_explosion%d.png", i + 1);
        g_enemy_explosion_frames[2][i] = al_load_bitmap(path);
        if (!g_enemy_explosion_frames[2][i]) { printf("Erro ao carregar %s\n", path); return false; }
    }

    for (int i = 0; i < 6; i++) {
        sprintf(path, "spaceship_explosion%d.png", i + 1);
        g_player_explosion_frames[i] = al_load_bitmap(path);
        if (!g_player_explosion_frames[i]) { fprintf(stderr, "Erro ao carregar %s\n", path); return false; }
    }

    g_player_w = al_get_bitmap_width(g_player_frames[0]);
    g_player_h = al_get_bitmap_height(g_player_frames[0]);

    g_menu_font = al_load_font("PressStart2P-Regular.ttf", 12, 0);
    if (!g_menu_font) { fprintf(stderr, "Erro ao carregar fonte do menu (PressStart2P-Regular.ttf). Verifique se o arquivo esta na pasta do executavel.\n"); return false; }

    g_game_font = al_load_font("PressStart2P-Regular.ttf", 14, 0);
    if (!g_game_font) { fprintf(stderr, "Erro ao carregar fonte do jogo (PressStart2P-Regular.ttf). Verifique se o arquivo esta na pasta do executavel.\n"); return false; }

    return true;
}

void destroy_assets() {
    for (int i = 0; i < 4; i++) {
        al_destroy_bitmap(g_player_knockback_frames[i]);
        al_destroy_bitmap(g_player_knockback_left_frames[i]);
        al_destroy_bitmap(g_player_knockback_right_frames[i]);
        al_destroy_bitmap(g_player_frames[i]);
        al_destroy_bitmap(g_player_left_frames[i]);
        al_destroy_bitmap(g_player_right_frames[i]);
        al_destroy_bitmap(g_player_bullet_frames[i]);
    }
    for (int t = 0; t < 3; t++) {
        for (int i = 0; i < 6; i++) {
        al_destroy_bitmap(g_enemy_explosion_frames[t][i]);
        }
    }
    for (int i = 0; i < 6; i++) {
        al_destroy_bitmap(g_player_explosion_frames[i]);
    }
    for (int t = 0; t < 3; t++) {
        for (int i = 0; i < 2; i++) {
            al_destroy_bitmap(g_enemy_sprites[t][i]);
        }
    }

    al_destroy_bitmap(g_background);
    al_destroy_bitmap(g_interface_Move);
    al_destroy_bitmap(g_interface_SPACE);
    al_destroy_bitmap(g_logo);
    al_destroy_bitmap(g_enemy_bullet_sprite);

    al_destroy_sample_instance(g_musica2_instance);
    al_destroy_sample_instance(g_musica2_1_instance);
    al_destroy_sample_instance(g_musica2_2_instance);

    al_destroy_sample(g_musica1);
    al_destroy_sample(g_musica2);
    al_destroy_sample(g_musica2_1);
    al_destroy_sample(g_musica2_2);
    al_destroy_sample(g_sfx_shot);
    al_destroy_sample(g_sfx_button);
    al_destroy_sample(g_sfx_boom);

    al_destroy_font(g_menu_font);
    al_destroy_font(g_game_font);
}

void play_game_music(ALLEGRO_SAMPLE_INSTANCE *new_music_instance) {
    if (current_game_music_instance == new_music_instance) {
        return;
    }
    if (current_game_music_instance != NULL) {
        al_stop_sample_instance(current_game_music_instance);
    }
    al_set_sample_instance_gain(new_music_instance, 0.9);
    al_set_sample_instance_playmode(new_music_instance, ALLEGRO_PLAYMODE_LOOP);
    al_play_sample_instance(new_music_instance);
    current_game_music_instance = new_music_instance;
}


void reset_game_state() {
    free_shots(&g_shot_list);
    g_shot_list = NULL;

    EnemyShot *curr_shot;
    while (g_enemy_shots) {
        curr_shot = g_enemy_shots;
        g_enemy_shots = g_enemy_shots->next;
        free(curr_shot);
    }
    g_enemy_shots = NULL;

    Enemy *curr_enemy;
    while (g_enemy_list) {
        curr_enemy = g_enemy_list;
        g_enemy_list = g_enemy_list->next;
        free(curr_enemy);
    }
    g_enemy_list = NULL;

    create_enemy_group(&g_enemy_list);

    g_player_exploding = false;
    g_player_explosion_frame = 0;
    g_player_explosion_timer = 0.0f;
    g_player_x = (SCREEN_W - g_player_w * g_player_scale) / 2;
    g_player_y = SCREEN_H - g_player_h * g_player_scale - 100;

    g_moving_right = true;
    g_enemy_dx = 2.0;
    g_enemy_step_interval = 0.3f;

    if (current_game_music_instance != NULL) {
        al_stop_sample_instance(current_game_music_instance);
        current_game_music_instance = NULL;
    }
    al_stop_sample(&g_musica1_id);
}


void run_menu() {
    bool esperando_inicio = true;
    float backg_y = 0, backg_speed = 2.0;
    float blink_timer = 0.0f;
    bool show_text = true;
    int current_frame = 0;
    float frame_time = 0;


    g_enemy_speed_multiplier = 1.0f;
    g_current_round = 1;
    g_score = 0;


    al_play_sample(g_musica1, 0.9, 0.0, 1.0, ALLEGRO_PLAYMODE_LOOP, &g_musica1_id);

    while (esperando_inicio) {
        ALLEGRO_EVENT evento;
        al_wait_for_event(g_event_queue, &evento);

        if (evento.type == ALLEGRO_EVENT_DISPLAY_CLOSE) {
            esperando_inicio = false;
            current_game_state = -1;
        } else if (evento.type == ALLEGRO_EVENT_KEY_DOWN) {
            if (evento.keyboard.keycode == ALLEGRO_KEY_ENTER) {
                al_play_sample(g_sfx_button, 2.8, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, NULL);
                al_stop_sample(&g_musica1_id);
                reset_game_state();
                current_game_state = PLAYING;
                esperando_inicio = false;
            } else if (evento.keyboard.keycode == ALLEGRO_KEY_ESCAPE) {
                esperando_inicio = false;
                current_game_state = -1;
            }
        }
        if (evento.type == ALLEGRO_EVENT_TIMER) {
            backg_y += backg_speed;
            if (backg_y >= SCREEN_H) backg_y = 0;

            blink_timer += 1.0 / FPS;
            if (blink_timer >= 0.5) {
                blink_timer = 0;
                show_text = !show_text;
            }

            frame_time += 1.0 / FPS;
            if (frame_time >= 0.10) {
                frame_time = 0;
                current_frame = (current_frame + 1) % 4;
            }

            al_clear_to_color(al_map_rgb(0, 0, 0));
            al_draw_scaled_bitmap(g_background, 0, 0,
                al_get_bitmap_width(g_background), al_get_bitmap_height(g_background),
                0, backg_y, SCREEN_W, SCREEN_H, 0);
            al_draw_scaled_bitmap(g_background, 0, 0,
                al_get_bitmap_width(g_background), al_get_bitmap_height(g_background),
                0, backg_y - SCREEN_H, SCREEN_W, SCREEN_H, 0);

            float player_menu_x = (SCREEN_W - g_player_w * g_player_scale) / 2;
            float player_menu_y = SCREEN_H - g_player_h * g_player_scale - 100;
            al_draw_scaled_bitmap(g_player_frames[current_frame], 0, 0, g_player_w, g_player_h,
                player_menu_x, player_menu_y, g_player_w * g_player_scale, g_player_h * g_player_scale, 0);

            int w_interface_Move = al_get_bitmap_width(g_interface_Move);
            int h_interface_Move = al_get_bitmap_height(g_interface_Move);
            float scale_interface = 1.90;
            al_draw_scaled_bitmap(g_interface_Move, 0, 0, w_interface_Move, h_interface_Move,
                SCREEN_W - 1005, 595, w_interface_Move * scale_interface, h_interface_Move * scale_interface, 0);

            int w_interface_SPACE = al_get_bitmap_width(g_interface_SPACE);
            int h_interface_SPACE = al_get_bitmap_height(g_interface_SPACE);
            al_draw_scaled_bitmap(g_interface_SPACE, 0, 0, w_interface_SPACE, h_interface_SPACE,
                SCREEN_W - 903, 627, w_interface_SPACE * scale_interface, h_interface_SPACE * scale_interface, 0);

            int w_logo = al_get_bitmap_width(g_logo);
            int h_logo = al_get_bitmap_height(g_logo);
            al_draw_scaled_bitmap(g_logo, 0, 0, w_logo, h_logo,
                SCREEN_W / 2 -220, SCREEN_H / 2 -290, w_logo * scale_interface, h_logo * scale_interface, 0);

            if (show_text) {
                al_draw_text(g_menu_font, al_map_rgb(255, 255, 255), SCREEN_W / 2, SCREEN_H / 2,
                             ALLEGRO_ALIGN_CENTER, "PRESSIONE ENTER PARA INICIAR");
            }
            char menu_high_score_text[64];
            sprintf(menu_high_score_text, "HIGH SCORE: %d", g_high_score);
            al_draw_text(g_menu_font, al_map_rgb(0, 255, 255), SCREEN_W / 2, SCREEN_H / 2 + 40, ALLEGRO_ALIGN_CENTER, menu_high_score_text);
                    
            al_flip_display();
        }
    }
}


void run_game() {
    bool playing = true;
    float speed = 6.0;
    bool idle = false;
    bool left_key = false;
    bool right_key = false;
    float time_per_frame = 0.10;
    int current_frame = 0;
    float frame_time = 0;
    float shoot_cooldown = 1.0;
    float shoot_timer = 0.0;
    float backg_y = 0, backg_speed = 2.0;
    bool knockback_active = false;
    int knockback_frame = 0;
    float knockback_time = 0;
    const float knockback_duration = 0.3;
    const float knockback_frame_time = knockback_duration / 4;
    int player_direction = 0;

    current_game_music_instance = NULL;

    while (playing) {
        ALLEGRO_EVENT ev;
        al_wait_for_event(g_event_queue, &ev);

        if (ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE) {
            playing = false;
            current_game_state = -1;
        }
        else if (ev.type == ALLEGRO_EVENT_KEY_DOWN) {
            if (ev.keyboard.keycode == ALLEGRO_KEY_LEFT) left_key = true;
            if (ev.keyboard.keycode == ALLEGRO_KEY_RIGHT) right_key = true;
            if (ev.keyboard.keycode == ALLEGRO_KEY_P || ev.keyboard.keycode == ALLEGRO_KEY_ESCAPE) {
                al_play_sample(g_sfx_button, 2.8, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, NULL);
                playing = false;
                current_game_state = PAUSED;
            }
        } else if (ev.type == ALLEGRO_EVENT_KEY_UP) {
            if (ev.keyboard.keycode == ALLEGRO_KEY_LEFT) left_key = false;
            if (ev.keyboard.keycode == ALLEGRO_KEY_RIGHT) right_key = false;
        }
        
        else if (ev.type == ALLEGRO_EVENT_TIMER) {
            float delta_time = 1.0 / FPS;

            ALLEGRO_KEYBOARD_STATE key_state;
            al_get_keyboard_state(&key_state); 

            int total_enemies = g_rows * g_cols;
            int alive = count_alive_enemies(g_enemy_list);
            float percent_alive = (float)alive / total_enemies;
            float factor = 1.0f - pow(percent_alive,2);
            g_enemy_step_interval = (0.3f - factor * 0.2f) / g_enemy_speed_multiplier;
            float base_speed = 5.0f;

            if (percent_alive >= 0.5) {
                g_enemy_dx = (base_speed + 5 * factor) * g_enemy_speed_multiplier; 
                play_game_music(g_musica2_instance);
            } else if (percent_alive < 0.5 && percent_alive >= 0.2) {
                g_enemy_dx = (base_speed + 7 * factor) * g_enemy_speed_multiplier; 
                play_game_music(g_musica2_1_instance);
            } else if (percent_alive < 0.2 && alive > 1) {
                g_enemy_dx = (base_speed + 10 * factor) * g_enemy_speed_multiplier; 
                play_game_music(g_musica2_2_instance);
            } else if (alive == 1) {
                g_enemy_dx = (base_speed + 40 * factor) * g_enemy_speed_multiplier; 
                play_game_music(g_musica2_2_instance);
            } else {
                g_enemy_dx = 0; 
                playing = false; 

                check_and_save_high_score(); 

                g_enemy_speed_multiplier *= SPEED_INCREASE_FACTOR; 
                g_current_round++; 
               
                current_game_state = ROUND_TRANSITION; 
            }

            if (g_enemy_shots == NULL && alive > 0) { 
                Enemy *frontline[MAX_COLS];
                get_frontline_enemies(g_enemy_list, frontline);

                int col = rand() % MAX_COLS;
                if (frontline[col]) {
                    add_enemy_shot(frontline[col]->x + (g_enemy_w * g_enemy_scale) / 2,
                                   frontline[col]->y + (g_enemy_h * g_enemy_scale));
                }
            }

            update_enemy_shots();
            check_bullet_collision(&g_shot_list, g_enemy_list);
            update_enemies(g_enemy_list, delta_time);

            if (g_player_exploding) {
                g_player_explosion_timer += delta_time;
                if (g_player_explosion_timer >= 0.1f) {
                    g_player_explosion_timer = 0;
                    g_player_explosion_frame++;
                    if (g_player_explosion_frame >= 6) {
                        playing = false; 
                        current_game_state = GAME_OVER;
                    }
                }
            } else { 
                if (check_game_over_conditions(g_enemy_list, g_player_y) || check_enemy_shot_collision_with_player(&g_enemy_shots, g_player_x, g_player_y, g_player_w, g_player_h, g_player_scale)) {
                    g_player_exploding = true;
                    g_player_explosion_frame = 0;
                    g_player_explosion_timer = 0.0f;
                }
            }


            if (shoot_timer > 0.0) shoot_timer -= delta_time;

            if ((shoot_timer <= 0.0 && g_shot_list == NULL) && (al_key_down(&key_state, ALLEGRO_KEY_SPACE))) {
                add_shot(g_player_x, g_player_y, g_player_w, g_player_scale, &g_shot_list);
                knockback_active = true;
                knockback_frame = 0;
                knockback_time = 0;
                shoot_timer = shoot_cooldown;
                al_play_sample(g_sfx_shot, 1.1, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, NULL);
            }


            if (knockback_active) {
                knockback_time += delta_time;
                if (knockback_time >= knockback_duration)
                    knockback_active = false;
                else {
                    knockback_frame = (int)(knockback_time / knockback_frame_time);
                    if (knockback_frame > 3) knockback_frame = 3;
                }
            }

            backg_y += backg_speed;
            if (backg_y >= SCREEN_H) backg_y = 0;

            idle = false;
            player_direction = 0;
            if (left_key) {
                g_player_x -= speed;
                idle = true;
                player_direction = -1;
            }
            if (right_key) {
                g_player_x += speed;
                idle = true;
                player_direction = 1;
            }

            frame_time += delta_time;
            if (frame_time >= time_per_frame) {
                frame_time = 0;
                current_frame = (current_frame + 1) % 4;
            }

            if (g_player_x < 0) g_player_x = 0;
            if (g_player_x > SCREEN_W - g_player_w * g_player_scale) g_player_x = SCREEN_W - g_player_w * g_player_scale;

            al_clear_to_color(al_map_rgb(0, 0, 0));
            al_draw_scaled_bitmap(g_background, 0, 0, al_get_bitmap_width(g_background), al_get_bitmap_height(g_background), 0, backg_y, SCREEN_W, SCREEN_H, 0);
            al_draw_scaled_bitmap(g_background, 0, 0, al_get_bitmap_width(g_background), al_get_bitmap_height(g_background), 0, backg_y - SCREEN_H, SCREEN_W, SCREEN_H, 0);

            al_draw_line(0, ENEMY_GAME_OVER_LINE_Y, SCREEN_W, ENEMY_GAME_OVER_LINE_Y, al_map_rgb(0, 128, 128), 2);

            if (g_player_exploding) {
                if (g_player_explosion_frame < 6) {
                    ALLEGRO_BITMAP *expl = g_player_explosion_frames[g_player_explosion_frame];
                    al_draw_scaled_bitmap(expl, 0, 0,
                        al_get_bitmap_width(expl), al_get_bitmap_height(expl),
                        g_player_x, g_player_y,
                        g_player_w * g_player_scale, g_player_h * g_player_scale,
                        0
                    );
                }
            } else {
                if (knockback_active) {
                    ALLEGRO_BITMAP *kb_frame;
                    // Use knockback_frame para todas as direções de knockback
                    if (player_direction == -1) {
                        kb_frame = g_player_knockback_left_frames[knockback_frame];
                    } else if (player_direction == 1) {
                        kb_frame = g_player_knockback_right_frames[knockback_frame];
                    } else {
                        kb_frame = g_player_knockback_frames[knockback_frame];
                    }

                    int kb_width = al_get_bitmap_width(kb_frame);
                    int kb_height = al_get_bitmap_height(kb_frame);

                    al_draw_scaled_bitmap(kb_frame, 0, 0, kb_width, kb_height,
                        g_player_x, g_player_y, kb_width * g_player_scale, kb_height * g_player_scale, 0);
                } else if (idle) {
                    // Mantenha esta lógica para quando não há knockback, mas há movimento
                    ALLEGRO_BITMAP *frame = player_direction == 1 ? g_player_right_frames[current_frame] : g_player_left_frames[current_frame];
                    al_draw_scaled_bitmap(frame, 0, 0, g_player_w, g_player_h, g_player_x, g_player_y, g_player_w * g_player_scale, g_player_h * g_player_scale, 0);
                } else {
                    // Mantenha esta lógica para quando não há knockback e está parado
                    al_draw_scaled_bitmap(g_player_frames[current_frame], 0, 0, g_player_w, g_player_h, g_player_x, g_player_y, g_player_w * g_player_scale, g_player_h * g_player_scale, 0);
                }
            }

            update_shots(&g_shot_list);
            draw_shots(g_shot_list);
            draw_enemies(g_enemy_list, delta_time);
            draw_enemy_shots();

            char score_text[32];
            sprintf(score_text, "SCORE: %04d", g_score);
            al_draw_text(g_game_font, al_map_rgb(255, 255, 255), 30, 30, 0, score_text);

            al_flip_display();
        }
    }
    if (current_game_music_instance != NULL) {
        al_stop_sample_instance(current_game_music_instance);
        current_game_music_instance = NULL;
    }
}

void run_game_over() {
    bool game_over_screen_active = true;

    if (current_game_music_instance != NULL) {
        al_stop_sample_instance(current_game_music_instance);
        current_game_music_instance = NULL;
    }

    check_and_save_high_score();
    g_enemy_speed_multiplier = 1.0f;
    g_current_round = 1;


    while (game_over_screen_active) {
        ALLEGRO_EVENT ev;
        al_wait_for_event(g_event_queue, &ev);

        if (ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE) {
            game_over_screen_active = false;
            current_game_state = -1;
        } else if (ev.type == ALLEGRO_EVENT_KEY_DOWN) {
            if (ev.keyboard.keycode == ALLEGRO_KEY_ESCAPE) {
                al_play_sample(g_sfx_button, 2.8, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, NULL);
                game_over_screen_active = false;
                current_game_state = MENU;
            } else if (ev.keyboard.keycode == ALLEGRO_KEY_ENTER) {
                al_play_sample(g_sfx_button, 2.8, 0.0, 1.0, ALLEGRO_PLAYMODE_ONCE, NULL);
                g_score = 0;
                reset_game_state();
                game_over_screen_active = false;
                current_game_state = PLAYING;
            }
        }
        else if (ev.type == ALLEGRO_EVENT_TIMER) {
            al_clear_to_color(al_map_rgb(0, 0, 0));

            al_draw_text(g_game_font, al_map_rgb(255, 0, 0), SCREEN_W / 2, SCREEN_H / 2 - 40, ALLEGRO_ALIGN_CENTER, "GAME OVER");

            char score_text[64];
            sprintf(score_text, "SCORE FINAL: %d", g_score);
            al_draw_text(g_game_font, al_map_rgb(255, 255, 255), SCREEN_W / 2, SCREEN_H / 2 + 10, ALLEGRO_ALIGN_CENTER, score_text);

            char high_score_text[64];
            sprintf(high_score_text, "HIGH SCORE: %d", g_high_score);
            al_draw_text(g_game_font, al_map_rgb(0, 255, 255), SCREEN_W / 2, SCREEN_H / 2 + 35, ALLEGRO_ALIGN_CENTER, high_score_text);

            al_draw_text(g_game_font, al_map_rgb(200, 200, 200), SCREEN_W / 2, SCREEN_H / 2 + 60, ALLEGRO_ALIGN_CENTER, "Pressione ESC para o menu");
            al_draw_text(g_game_font, al_map_rgb(200, 200, 200), SCREEN_W / 2, SCREEN_H / 2 + 80, ALLEGRO_ALIGN_CENTER, "Pressione ENTER para jogar novamente");
            al_flip_display();
        }
    }
}


int main(void) {
    srand(time(NULL));

    if (!al_init()) { fprintf(stderr, "Falha ao inicializar Allegro.\n"); return -1; }
    if (!al_init_image_addon()) { fprintf(stderr, "Falha ao inicializar addon de imagem.\n"); return -1; }
    if (!al_init_primitives_addon()) { fprintf(stderr, "Falha ao inicializar addon de primitivas.\n"); return -1; }
    if (!al_install_keyboard()) { fprintf(stderr, "Falha ao instalar teclado.\n"); return -1; }
    if (!al_install_audio()) { fprintf(stderr, "Falha ao inicializar audio.\n"); return -1; }
    if (!al_init_acodec_addon()) { fprintf(stderr, "Falha ao inicializar acodec.\n"); return -1; }
    if (!al_reserve_samples(7)) { fprintf(stderr, "Falha ao reservar samples de audio.\n"); return -1; }
    al_init_font_addon();
    if (!al_init_ttf_addon()) { fprintf(stderr, "Falha ao inicializar addon de ttf.\n"); return -1; }


    g_display = al_create_display(SCREEN_W, SCREEN_H);
    if (!g_display) { fprintf(stderr, "Falha ao criar display.\n"); return -1; }

    g_event_queue = al_create_event_queue();
    if (!g_event_queue) { fprintf(stderr, "Falha ao criar fila de eventos.\n"); al_destroy_display(g_display); return -1; }

    g_timer = al_create_timer(1.0 / FPS);
    if (!g_timer) { fprintf(stderr, "Falha ao criar timer.\n"); al_destroy_event_queue(g_event_queue); al_destroy_display(g_display); return -1; }

    al_register_event_source(g_event_queue, al_get_keyboard_event_source());
    al_register_event_source(g_event_queue, al_get_display_event_source(g_display));
    al_register_event_source(g_event_queue, al_get_timer_event_source(g_timer));


    al_start_timer(g_timer);

    if (!load_assets()) {
        fprintf(stderr, "Erro ao carregar assets. Verifique os arquivos de imagem/audio.\n");
        destroy_assets();
        al_destroy_timer(g_timer);
        al_destroy_event_queue(g_event_queue);
        al_destroy_display(g_display);
        return -1;
    }

    load_high_score();

    while (current_game_state != -1) {
        switch (current_game_state) {
            case MENU:
                run_menu();
                break;
            case PLAYING:
                run_game();
                break;
            case PAUSED:
                run_paused();
                break;
            case ROUND_TRANSITION:
                run_round_transition();
                break;
            case GAME_OVER:
                run_game_over();
                break;
        }
    }

    destroy_assets();
    al_destroy_timer(g_timer);
    al_destroy_event_queue(g_event_queue);
    al_destroy_display(g_display);

    return 0;
}