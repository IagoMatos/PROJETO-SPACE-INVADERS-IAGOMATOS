#include <allegro5/allegro.h>

int main() {
    al_init(); // Inicializa o Allegro
    return 0;
}
